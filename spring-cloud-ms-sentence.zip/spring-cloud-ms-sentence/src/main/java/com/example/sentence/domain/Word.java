package com.example.sentence.domain;

public class Word {
	private String text;
	private String dato;
	public void setText(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
}
