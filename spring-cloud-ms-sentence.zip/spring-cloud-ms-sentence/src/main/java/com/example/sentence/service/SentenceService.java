package com.example.sentence.service;

public interface SentenceService {

	String buildSentence();

}
