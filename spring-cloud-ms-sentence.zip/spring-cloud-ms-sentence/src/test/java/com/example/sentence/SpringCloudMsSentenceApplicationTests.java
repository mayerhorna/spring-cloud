package com.example.sentence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudMsSentenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
